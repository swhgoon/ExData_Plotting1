#!/bin/bash
/usr/bin/R -f plotall.R